import org.junit.jupiter.api.Test;

import java.awt.desktop.FilesEvent;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

public class GuessNumberRandomnessTest {

  static int MIN = 1;
  static int MAX = 100;
  static double FREQ_DIFF = 0.50;
  static int NUM_RUNS = 30000;
  static Random rand = new Random(0);

  @Test
  void testDistributionOfRandomNumber() {
    HashMap<Integer, Integer> freqMap = new HashMap<>();

    for (int i = 0; i < NUM_RUNS; i++) {
      // user input does not matter
      byte[] data = "1\n2\n3\n4\n5\n".getBytes(StandardCharsets.UTF_8);

      BufferedInputStream in = new BufferedInputStream(new ByteArrayInputStream(data));
      System.setIn(in);
      ByteArrayOutputStream output = new ByteArrayOutputStream();
      System.setOut(new PrintStream(output));

      // use the same seed for each run
      int guess = GuessNumber.guessingNumberGame(rand);
      freqMap.put(guess, freqMap.getOrDefault(guess, 0) + 1);

      System.setIn(System.in);
      System.setOut(System.out);
    }

    double expectedFreq = (double) NUM_RUNS / (MAX - MIN + 1);
    double lower = expectedFreq * (1 - FREQ_DIFF);
    double upper = expectedFreq * (1 + FREQ_DIFF);

    for (int i = MIN; i <= MAX; i++) {
      int actualFreq = freqMap.getOrDefault(i, 0);
      if (lower <= actualFreq && actualFreq <= upper) {
        continue;
      } else {
        fail("frequency of " + i + " is not within +50%/-50% range!\n" +
                "It has a frequency of " + actualFreq + "\n");
      }
    }
  }

}
