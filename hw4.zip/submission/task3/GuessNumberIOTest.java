import org.junit.jupiter.api.*;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.util.Random;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

public class GuessNumberIOTest {
  static int SEED = 1;
  static Random rand;

  @BeforeEach
  void setup() {
    rand = new Random(SEED); // guess is 86
  }

  @AfterEach
  void reset() {
    System.setIn(System.in);
    System.setOut(System.out);
  }


  @Test
  void testAllSmaller () {

    byte[] data = "1\n2\n3\n4\n5\n86\n".getBytes(StandardCharsets.UTF_8);
    BufferedInputStream in = new BufferedInputStream(new ByteArrayInputStream(data));
    ByteArrayOutputStream output = new ByteArrayOutputStream();

    System.setIn(in); System.setOut(new PrintStream(output));

    GuessNumber.guessingNumberGame(rand);

    String exp = "A number is chosen between 1 to 100. Guess the number within 5 trials.\n" +
            "Guess the number: The number is greater than 1\n" +
            "Guess the number: The number is greater than 2\n" +
            "Guess the number: The number is greater than 3\n" +
            "Guess the number: The number is greater than 4\n" +
            "Guess the number: The number is greater than 5\n" +
            "You have exhausted 5 trials.\n" +
            "The number was 86\n";
    assertEquals(exp, output.toString());

  }

  // The program did not generate range message "The number is less than 99" on the fifth trial.
  // The fault may be that there is an off-by-one error in using the index so that the output message was skipped
  // on the fifth trial.
  // See `testLessOnLastTrial` for pattern detection.
  @Test
  void testAllLarger () {

    byte[] data = "99\n99\n99\n99\n99\n".getBytes(StandardCharsets.UTF_8);
    BufferedInputStream in = new BufferedInputStream(new ByteArrayInputStream(data));
    ByteArrayOutputStream output = new ByteArrayOutputStream();

    System.setIn(in); System.setOut(new PrintStream(output));

    GuessNumber.guessingNumberGame(rand);

    String exp = "A number is chosen between 1 to 100. Guess the number within 5 trials.\n" +
            "Guess the number: The number is less than 99\n" +
            "Guess the number: The number is less than 99\n" +
            "Guess the number: The number is less than 99\n" +
            "Guess the number: The number is less than 99\n" +
            "Guess the number: The number is less than 99\n" +
            "You have exhausted 5 trials.\n" +
            "The number was 86\n";
    assertEquals(exp, output.toString());
  }

  @Test
  void testAllSmallerCorrectOnFifth () {

    byte[] data = "1\n2\n3\n4\n86\n".getBytes(StandardCharsets.UTF_8);
    BufferedInputStream in = new BufferedInputStream(new ByteArrayInputStream(data));
    ByteArrayOutputStream output = new ByteArrayOutputStream();

    System.setIn(in); System.setOut(new PrintStream(output));

    GuessNumber.guessingNumberGame(rand);

    String exp = "A number is chosen between 1 to 100. Guess the number within 5 trials.\n" +
            "Guess the number: The number is greater than 1\n" +
            "Guess the number: The number is greater than 2\n" +
            "Guess the number: The number is greater than 3\n" +
            "Guess the number: The number is greater than 4\n" +
            "Guess the number: Congratulations! You guessed the number.\n";
    assertEquals(exp, output.toString());
  }

  @Test
  void testAllLargerCorrectOnFifth () {

    byte[] data = "100\n100\n100\n100\n86\n".getBytes(StandardCharsets.UTF_8);
    BufferedInputStream in = new BufferedInputStream(new ByteArrayInputStream(data));
    ByteArrayOutputStream output = new ByteArrayOutputStream();

    System.setIn(in); System.setOut(new PrintStream(output));

    GuessNumber.guessingNumberGame(rand);

    String exp = "A number is chosen between 1 to 100. Guess the number within 5 trials.\n" +
            "Guess the number: The number is less than 100\n" +
            "Guess the number: The number is less than 100\n" +
            "Guess the number: The number is less than 100\n" +
            "Guess the number: The number is less than 100\n" +
            "Guess the number: Congratulations! You guessed the number.\n";
    assertEquals(exp, output.toString());
  }



  @Test
  void testAllSmallerCorrectOnFourth () {

    byte[] data = "1\n2\n3\n86\n".getBytes(StandardCharsets.UTF_8);
    BufferedInputStream in = new BufferedInputStream(new ByteArrayInputStream(data));
    ByteArrayOutputStream output = new ByteArrayOutputStream();

    System.setIn(in); System.setOut(new PrintStream(output));

    GuessNumber.guessingNumberGame(rand);

    String exp = "A number is chosen between 1 to 100. Guess the number within 5 trials.\n" +
            "Guess the number: The number is greater than 1\n" +
            "Guess the number: The number is greater than 2\n" +
            "Guess the number: The number is greater than 3\n" +
            "Guess the number: Congratulations! You guessed the number.\n";
    assertEquals(exp, output.toString());

  }


  @Test
  void testAllLargerCorrectOnFourth () {

    byte[] data = "100\n100\n100\n86\n".getBytes(StandardCharsets.UTF_8);
    BufferedInputStream in = new BufferedInputStream(new ByteArrayInputStream(data));
    ByteArrayOutputStream output = new ByteArrayOutputStream();

    System.setIn(in); System.setOut(new PrintStream(output));

    GuessNumber.guessingNumberGame(rand);

    String exp = "A number is chosen between 1 to 100. Guess the number within 5 trials.\n" +
            "Guess the number: The number is less than 100\n" +
            "Guess the number: The number is less than 100\n" +
            "Guess the number: The number is less than 100\n" +
            "Guess the number: Congratulations! You guessed the number.\n";
    assertEquals(exp, output.toString());
  }

  @Test
  void testAllSmallerCorrectOnThird () {

    byte[] data = "1\n2\n86\n".getBytes(StandardCharsets.UTF_8);
    BufferedInputStream in = new BufferedInputStream(new ByteArrayInputStream(data));
    ByteArrayOutputStream output = new ByteArrayOutputStream();

    System.setIn(in); System.setOut(new PrintStream(output));

    GuessNumber.guessingNumberGame(rand);

    String exp = "A number is chosen between 1 to 100. Guess the number within 5 trials.\n" +
            "Guess the number: The number is greater than 1\n" +
            "Guess the number: The number is greater than 2\n" +
            "Guess the number: Congratulations! You guessed the number.\n";
    assertEquals(exp, output.toString());

  }

  @Test
  void testAllLargerCorrectOnThird () {

    byte[] data = "100\n100\n86\n".getBytes(StandardCharsets.UTF_8);
    BufferedInputStream in = new BufferedInputStream(new ByteArrayInputStream(data));
    ByteArrayOutputStream output = new ByteArrayOutputStream();

    System.setIn(in); System.setOut(new PrintStream(output));

    GuessNumber.guessingNumberGame(rand);

    String exp = "A number is chosen between 1 to 100. Guess the number within 5 trials.\n" +
            "Guess the number: The number is less than 100\n" +
            "Guess the number: The number is less than 100\n" +
            "Guess the number: Congratulations! You guessed the number.\n";
    assertEquals(exp, output.toString());
  }

  @Test
  void testAllSmallerCorrectOnSecond () {

    byte[] data = "1\n86\n".getBytes(StandardCharsets.UTF_8);
    BufferedInputStream in = new BufferedInputStream(new ByteArrayInputStream(data));
    ByteArrayOutputStream output = new ByteArrayOutputStream();

    System.setIn(in); System.setOut(new PrintStream(output));

    GuessNumber.guessingNumberGame(rand);

    String exp = "A number is chosen between 1 to 100. Guess the number within 5 trials.\n" +
            "Guess the number: The number is greater than 1\n" +
            "Guess the number: Congratulations! You guessed the number.\n";
    assertEquals(exp, output.toString());

  }

  @Test
  void testAllLargerCorrectOnSecond () {

    byte[] data = "100\n86\n".getBytes(StandardCharsets.UTF_8);
    BufferedInputStream in = new BufferedInputStream(new ByteArrayInputStream(data));
    ByteArrayOutputStream output = new ByteArrayOutputStream();

    System.setIn(in); System.setOut(new PrintStream(output));

    GuessNumber.guessingNumberGame(rand);

    String exp = "A number is chosen between 1 to 100. Guess the number within 5 trials.\n" +
            "Guess the number: The number is less than 100\n" +
            "Guess the number: Congratulations! You guessed the number.\n";
    assertEquals(exp, output.toString());
  }

  @Test
  void testCorrectOnFirst () {

    byte[] data = "86\n".getBytes(StandardCharsets.UTF_8);
    BufferedInputStream in = new BufferedInputStream(new ByteArrayInputStream(data));
    ByteArrayOutputStream output = new ByteArrayOutputStream();

    System.setIn(in); System.setOut(new PrintStream(output));

    GuessNumber.guessingNumberGame(rand);

    String exp = "A number is chosen between 1 to 100. Guess the number within 5 trials.\n" +
            "Guess the number: Congratulations! You guessed the number.\n";
    assertEquals(exp, output.toString());

  }

  @Test
  void testInvalidInput() {
    byte[] data = "!!\n".getBytes(StandardCharsets.UTF_8);
    BufferedInputStream in = new BufferedInputStream(new ByteArrayInputStream(data));
    ByteArrayOutputStream output = new ByteArrayOutputStream();

    System.setIn(in); System.setOut(new PrintStream(output));

    try {
      GuessNumber.guessingNumberGame(rand);
      fail("Program accepted invalid input!");
    } catch (Exception e) {

    }

  }

  @Test
  void testNonIntegerInput() {
    byte[] data = "1.1\n".getBytes(StandardCharsets.UTF_8);
    BufferedInputStream in = new BufferedInputStream(new ByteArrayInputStream(data));
    ByteArrayOutputStream output = new ByteArrayOutputStream();

    System.setIn(in); System.setOut(new PrintStream(output));

    try {
      GuessNumber.guessingNumberGame(rand);
      fail("Program accepted non-integers!");
    } catch (Exception e) {

    }
  }

  @Test
  void testProgramReturnsGuessIfGuessCorrectly() {
    byte[] data = "86\n".getBytes(StandardCharsets.UTF_8);
    BufferedInputStream in = new BufferedInputStream(new ByteArrayInputStream(data));
    ByteArrayOutputStream output = new ByteArrayOutputStream();
    System.setIn(in); System.setOut(new PrintStream(output));
    assertEquals(86, GuessNumber.guessingNumberGame(rand));
  }

  @Test
  void testProgramReturnsGuessIfGuessWrong() {
    byte[] data = "1\n1\n1\n1\n1\n".getBytes(StandardCharsets.UTF_8);
    BufferedInputStream in = new BufferedInputStream(new ByteArrayInputStream(data));
    ByteArrayOutputStream output = new ByteArrayOutputStream();
    System.setIn(in); System.setOut(new PrintStream(output));
    assertEquals(86, GuessNumber.guessingNumberGame(rand));
  }


  // Repeated test to detect faulty pattern
  // The program always skipped the fifth trial message when the actual guess is greater than the user input.
  // The fault may be that when incrementing the trial number in the loop, the program decided to not output any message
  // in the last round.
  @RepeatedTest(20)
  void testLessOnLastTrial() {
    Random r = new Random();
    int number = 90 + r.nextInt(10); // randomly generates a number larger than guess (86) on fifth trial
    byte[] data = ("1\n1\n1\n1\n" + number + "\n").getBytes(StandardCharsets.UTF_8);
    BufferedInputStream in = new BufferedInputStream(new ByteArrayInputStream(data));
    ByteArrayOutputStream output = new ByteArrayOutputStream();

    System.setIn(in); System.setOut(new PrintStream(output));

    GuessNumber.guessingNumberGame(rand);

    String exp = "A number is chosen between 1 to 100. Guess the number within 5 trials.\n" +
            "Guess the number: The number is greater than 1\n" +
            "Guess the number: The number is greater than 1\n" +
            "Guess the number: The number is greater than 1\n" +
            "Guess the number: The number is greater than 1\n" +
            "Guess the number: The number is less than " + number + "\n" +
            "You have exhausted 5 trials.\n" +
            "The number was 86\n";
    assertEquals(exp, output.toString());
  }

  @Test
  void testMixedLargerAndSmaller() {
    byte[] data = ("1\n90\n2\n90\n3\n").getBytes(StandardCharsets.UTF_8);
    BufferedInputStream in = new BufferedInputStream(new ByteArrayInputStream(data));
    ByteArrayOutputStream output = new ByteArrayOutputStream();

    System.setIn(in); System.setOut(new PrintStream(output));

    GuessNumber.guessingNumberGame(rand);

    String exp = "A number is chosen between 1 to 100. Guess the number within 5 trials.\n" +
            "Guess the number: The number is greater than 1\n" +
            "Guess the number: The number is less than 90\n" +
            "Guess the number: The number is greater than 2\n" +
            "Guess the number: The number is less than 90\n" +
            "Guess the number: The number is greater than 3\n" +
            "You have exhausted 5 trials.\n" +
            "The number was 86\n";
    assertEquals(exp, output.toString());
  }

  @Test
  void testMoreThanFiveInputsDoesNotBreakProgram() {
    byte[] data = ("1\n90\n2\n90\n3\n4\n5\n").getBytes(StandardCharsets.UTF_8);
    BufferedInputStream in = new BufferedInputStream(new ByteArrayInputStream(data));
    ByteArrayOutputStream output = new ByteArrayOutputStream();

    System.setIn(in); System.setOut(new PrintStream(output));

    GuessNumber.guessingNumberGame(rand);

    String exp = "A number is chosen between 1 to 100. Guess the number within 5 trials.\n" +
            "Guess the number: The number is greater than 1\n" +
            "Guess the number: The number is less than 90\n" +
            "Guess the number: The number is greater than 2\n" +
            "Guess the number: The number is less than 90\n" +
            "Guess the number: The number is greater than 3\n" +
            "You have exhausted 5 trials.\n" +
            "The number was 86\n";
    assertEquals(exp, output.toString());
  }




}
