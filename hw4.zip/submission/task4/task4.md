github repo url: https://github.com/RosaGao/ci-helloworld.git

docker image url: https://hub.docker.com/r/rosagao/ci-helloworld