import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;



public class JsonplaceholderRestAPITest {

  @BeforeAll
  public static void setUp() {
    RestAssured.baseURI = "https://jsonplaceholder.typicode.com";
  }

  //[test 1]: when a GET request is sent to /albums endpoint, verify that an entry with the
  // title "omnis laborum odio" exists.
  @Test
  void testGetAlbumsHasTitle() {
    given()
            .when()
            .get("/albums")
            .then()
            .assertThat()
            .body("title", hasItem("omnis laborum odio"));

  }



  //[test 2]: when a GET request is sent to /comments endpoint, verify that the returned
  // JSON response contains at least 200 comments.
  @Test
  void testGetCommentsHasAtLeast200Comments() {
    given()
            .when()
            .get("/comments")
            .then()
            .assertThat()
            .body("size()", greaterThanOrEqualTo(200));
  }



  //[test 3]: when a GET request is sent to /users endpoint, verify that a user named "Ervin Howell"
  // with username "Antonette" and zipcode of "90566-7771" exists.
  @Test
  void testGetUsersErvinHowell() {
    given()
            .when()
            .get("/users")
            .then()
            .assertThat()
            .body("find { it.name == 'Ervin Howell' }.username", equalTo("Antonette"))
            .body("find { it.name == 'Ervin Howell' }.address.zipcode", equalTo("90566-7771"));

  }




  //[test 4]: when a GET request is sent to /comments endpoint, verify that there are comments from
  // people whose email address end in .biz.
  @Test
  void testGetCommentsEmailsEndInBiz() {
    given()
            .when()
            .get("/comments")
            .then()
            .assertThat()
            .body("email", hasItems(endsWith(".biz")));
  }




  //[test 5]: Create a new post by sending a http POST request to /posts endpoint with given info
  @Test
  void testPostPostsWithGivenBody() {
    String body = "{\"userId\": 11, " +
            "\"id\": 101, " +
            "\"title\": \"sunt aut facere repellat provident occaecati excepturi optio reprehenderit\", " +
            "\"body\": \"quia et suscipit suscipit recusandae consequuntur expedita et cum reprehenderit molestiae ut ut quas totam nostrum rerum est autem sunt rem eveniet architecto\"}";

    given()
            .contentType("application/json")
            .body(body)
            .when()
            .post("/posts")
            .then()
            .assertThat()
            .statusCode(201);


  }

}
